import * as Login from "./login";
export interface AppState {
  login: Login.AuthState;
}
